import UIKit

// MARK: - Exercises

// 1.1 Sum
func sum(a: Double, b: Double) {
    var sum = a + b
    print(sum)
}

// 1.2 Seconds
func seconds(){
    var secondsInAYear = 60 * 60 * 24 * 365
    print(secondsInAYear)
}

// 1.3 Pixels
func pixels(width: Int, height: Int) {
    var numberOfPixels = width * height
    print(numberOfPixels)
}

// 1.4 L Area
func lArea(width: Double, height: Double, x: Double, y: Double){
    var missingSide = height - y
    var perimeter = height + height + x + y + missingSide
    var area1 = x * missingSide
    var area2 = y * width
    var area = area1 + area2
}

// 1.5 Swap
func swap(a: Data, b: Data) {
    var a = a
    var b = b
    a = b
    b = a
}

// 1.6 Last digit
func lastDigit(digit: Int) {
    var lastDigit = digit % 10
    print(lastDigit)
}

// 1.7 Dog years
func convertDogYears(dogYears: Int) {
    var humanYears = dogYears / 7
    print(humanYears)
}

// 1.8 Brothers
var x = 3
var y = 2
var bob = 12
var alice = 27

// 1.9 Boys and girls
var numberOfBoys = 8
var numberOfGirls = 10
var totalNumber = 18

print(numberOfBoys / totalNumber)
print(numberOfGirls / totalNumber)

// 2.1 Max
func max(a: Int, b: Int) {
    if a > b {
        print(a)
    } else {
        print(b)
    }
}

// 2.2 Even or odd
func evenOrOdd(number: Int) {
    if number % 2 == 0 {
        print("even")
    } else {
        print("odd")
    }
}

// 2.3 Divisibility
func isDivisible(a: Int, b: Int) {
    if b == 0 {
        print("not divisible")
    } else {
        print("divisible")
    }
}

// 2.4 Two of the same
func twoOfTheSame(a: Int, b: Int, c:Int) {
    if a == b || a == c || b == c {
        print("at least two are the same")
    } else {
        print("all the values are different")
    }
}

// 2.5 Leap year
func leapYear(year: Int) {
    let isLeapYear = ((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0))
    if isLeapYear {
        print("Leap year!")
    } else {
        print("Not a leap year!")
    }
}

// 2.6 Coin toss
func coinToss() {
    var randomNumber = Int.random(in: 0 ... 100)
    if randomNumber % 2 == 0 {
        print("Heads")
    } else {
        print("Tails")
    }
}

// 2.7 Min 4
func min(a: Int, b: Int, c: Int, d: Int) {
    var numbers: [Int] = [a,b,c,d]
    var min = a
    
    for item in numbers {
        if item < numbers[item + 1] {
            min = item
        }
    }
}

// 2.8 Testing
func test(number: Int) {
    if ((number % 3 == 0) && (number % 5 != 0) && (number % 7 == 0)) {
        print("is divisible by 3,5 and 7")
    } else {
        print("not divisible by 3,5 and 7")
    }
}

// 2.9 Point
func findPoint(x: Int, y: Int, lowX: Int, lowY: Int, highX: Int, highY: Int) {
    if x > lowX && x < highX && y > lowY && y < highY {
        print("inside")
    } else {
        print("not inside")
    }
}

// 3.1 Average
func average(a: Double, b: Double) {
    var average = (a + b) / 2
    print(average)
}

// 3.2 Weighted average
func wightedAverage(finalsGrade: Double, midtermGrade: Double, projectGrade: Double, finalsAvg: Double, midtermAvg: Double, projectAvg: Double) {
    var finalGrade = (finalsAvg * finalsGrade) + (midtermAvg * midtermGrade) + (projectAvg * projectGrade)
    print(finalGrade)
}

// 3.3 Rounding
func round(number: Double) {
    String(format: "%.1f", number)
}

// 3.4 Above average
func aboveAverage(gradeA: Double, gradeB: Double, gradeC: Double, myGrade: Double) {
    let average = gradeA + gradeB + gradeC + myGrade
    
    if myGrade > average {
        print("above average")
    } else {
        print("below average")
    }
}

// 4.1 Chalkboard
func chalkboard(n: Int) {
    for _ in 0...n {
        print("I will not skip fundamentals")
    }
}

// 4.2 Squares
func squares(n: Int) {
    for i in 0...n {
        print(i * i)
    }
}

// 4.3 Powers of 2
func powersOfTwo(n: Int) {
    for i in 0...n {
        print(pow(2.0, n))
    }
}

// 4.4 Square
func printSquare(n: Int) {
    for _ in 1...n {
        for _ in 1...n {
            print("*", terminator: "")
        }
        print("")
    }
}

// 4.5 Rectangle
func printRectangle(n: Int, m: Int) {
    for _ in 1...n {
        for _ in 1...m {
            print("*", terminator: "")
        }
        print("")
    }
}

// 4.6 Triangle
func printTriangle(n: Int) {
    for i in 1...n {
        for _ in 1...i {
            print("*", terminator: "")
        }
        print("")
    }
}

// 4.7 Pyramid
func printPyramid(n: Int) {
    for i in 1...n {
        for j in 0..<(n-i) {
            print(" ", terminator: "")
        }

        for j in 1...2*i-1 {
            print("*", terminator: "")
        }
        print("")
    }
}

// 4.8 Leap years
func nextLeapYears(leapYear: Int, n: Int) {
    var count = 0
    var leapYear = leapYear
    
    while count < n {
        print(leapYear)
        count += 1
        leapYear += 4
        if leapYear % 100 == 0 && leapYear % 400 != 0 {
            leapYear += 4
        }
    }
}

// 4.9 GCD
func gcd(a: Int, b: Int) {
    var maxDiv = a
    var gcd = 1
    
    if b < maxDiv {
        maxDiv = b
    }
    
    for i in 1...maxDiv {
        if (a % i == 0) && (b % i == 0){
            gcd = i
        }
    }
    print(gcd)
}

// 4.10 Factoring numbers
func factorNumber(n: Int) {
    var number = n
    print("\(number) = ", terminator: "")
    var isFirst = true

    for i in 2...number {
        if number % i == 0 {
            while (number % i == 0) {
                number /= i

                if isFirst {
                    isFirst = false
                } else {
                    print(" * ", terminator: "")
                }
                print(i, terminator: "")
            }
        }
    }
}

// 5.1 Full name
var firstName = "Ralph"
var lastName = "Lauren"
var fullName = firstName + " " + lastName

// 5.2 Sum
var a = 14
var b = 23
var result = a + b
var formattedSum = "\(a) + \(b) = \(result)"

// 5.3 Replace
var aString = "Replace letter e with *"
var replacedString = ""

for character in aString {
    var char = "\(character)"
    if char == "e" {
        replacedString = replacedString + "*"
    } else {
        replacedString = replacedString + char
    }
}
print(replacedString)

// 5.4 Reverse
var anotherString = "Reverse"
var reverse = ""

for character in anotherString {
    var asString = "\(character)"
    reverse = asString + reverse
}
print(reverse)

// 5.5 Palindrome
var reversedString = ""

for character in aString {
    var asString = "\(character)"
    reversedString = asString + reversedString
}
print(aString == reversedString)

// 5.6 Words
var problem = "Split this string into words and print them on separate lines"
var word = ""

for character in problem {
    if character == " " {
        print(word)
        word = ""
    } else {
        word += "\(character)"
    }
}
print(word)

// 5.7 Long word
var anotherProblem = "find the longest word in the problem description"
anotherProblem += " "
var anotherWord = ""
var length = 0
var max = 0
var longestWord = ""

for character in anotherProblem {
    if character == " " {
        if length > max {
            max = length
            longestWord = anotherWord
        }
        anotherWord = ""
        length = 0
    } else {
        anotherWord += "\(character)"
        length += 1
    }
}
print(longestWord)

// 6.1 Max
var listOfNumbers = [1,2,3,10,100,2]
var maxNumber = listOfNumbers[0]

for number in listOfNumbers {
    if maxNumber < number {
        maxNumber = number
    }
}

// 6.2 Odd numbers
for number in listOfNumbers {
    if number % 2 == 1 {
        print(number)
    }
}

// 6.3 Sum
var sum = 0

for number in listOfNumbers {
    sum += number
}

// 6.4 Odd index
var i = 1

while i < listOfNumbers.count {
    print(listOfNumbers[i])
    i += 2
}

// 6.5 Going back
var j = listOfNumbers.count - 1

while j >= 0 {
    print(listOfNumbers[j])
    j -= 1
}

// 6.7 Sorted
listOfNumbers.sort(by: >)
print(listOfNumbers)

// 6.8 Search
var xNumber = 234
for number in listOfNumbers {
    if number == xNumber {
        print("yes")
    }
}

// 6.9 Intersection
var otherNumbers = [5,2,3,10,13]
for otherNumber in otherNumbers {
    for number in listOfNumbers {
        if number == otherNumber {
            print(number)
            break
        }
    }
}

// 6.10 Fibonacci
var fibonacci = [1, 1]
var N = 30

for i in 2...N - 1 {
    fibonacci.append(fibonacci[i-1] + fibonacci[i-2])
}

for number in fibonacci {
    print(number)
}

// 7.1 Min
func min2(_ a: Int, _ b: Int) -> Int{
    if a < b {
        return a
    } else {
        return b
    }
}

// 7.2 Last digit
func lastDigit(_ digit: Int) -> Int {
    return digit % 10
}

// 7.3 Prime numbers
func divides(_ a: Int, _ b: Int) -> Bool {
    return a % b == 0
}

func countDivisors(_ number: Int) -> Int {
    var cnt = 0
    
    for i in 1...number {
        if divides(number, i) {
            cnt += 1
        }
    }
    
    return cnt
}

func isPrime(_ number: Int) -> Bool {
    return countDivisors(number) == 2
}

// 7.4 Reverse
func reverse(numbers: [Int]) -> [Int] {
    var reversedArray: [Int] = []
    
    for number in numbers {
        reversedArray.insert(number, at: 0)
    }
    
    return reversedArray
}

// 7.5 Sum
func sumOfArray(numbers: [Int]) -> Int {
    var sumOfNumbers = 0
    
    for number in numbers {
        sumOfNumbers += number
    }
    
    return sumOfNumbers
}

// 7.6 Parse number
func parse(digit: String) -> Int {
    let digits = "0123456789"
    var result = 0

    for character in digits {
        var d = "\(character)"

        if d == digit {
            return result
        }
        result += 1
    }

    return -1
}

// 7.8 Stack
func push(_ number: Int, _ queue: inout [Int]) {
    queue.append(number)
}

func pop(_ queue: inout [Int]) -> Int? {
    var result = queue.first

    if queue.count > 0 {
        queue.remove(at: 0)
    }

    return result
}

// 7.9 Stack
func stackPush(_ number: Int, _ stack: inout [Int]) {
    stack.append(number)
}

func top(_ stack: [Int]) -> Int? {
    if stack.count == 0 {
        return nil
    }
    return stack[stack.count - 1]
}

func stackPop(_ stack: inout [Int]) -> Int? {
    var result = top(stack)

    if stack.count > 0 {
        stack.remove(at: stack.count - 1)
    }

    return result
}

// 10.1 Rock, paper, scissors
enum HandShape {
    case rock
    case paper
    case scissors
}

enum MatchResult {
    case win
    case draw
    case lose
}

func match(firstPlayer: HandShape, secondPlayer: HandShape) -> MatchResult {
    if firstPlayer == secondPlayer {
        return .draw
    }
    if firstPlayer == .rock && secondPlayer == .scissors {
        return .win
    }
    if firstPlayer == .paper && secondPlayer == .rock {
        return .win
    }
    if firstPlayer == .scissors && secondPlayer == .paper {
        return .win
    }

    return .lose
}

// 10.2 Min Max
func minMax(a: Int, b: Int) -> (Int,Int) {
    if a < b {
        return (a,b)
    } else {
        return (b,a)
    }
}

// 10.3 Fractions
func fractions(numerator: (Int, Int), denominator: (Int, Int)) -> (Int, Int) {
    let sumNumerator = (numerator.0 * denominator.1) + (numerator.1 * denominator.0)
    let sumDenominator = (numerator.1 * denominator.1)
    
    return (sumNumerator, sumDenominator)
}

// 10.4 Money
enum CoinType: Int {
    case penny = 1
    case nickle = 5
    case dime = 10
    case quarter = 25
}

var moneyArray:[(Int,CoinType)] = [(10,.penny),
                                   (15,.nickle),
                                   (3,.quarter),
                                   (20,.penny),
                                   (3,.dime),
                                   (7,.quarter)]
var totalMoney = 0

for (amount, coinType) in moneyArray {
    totalMoney += amount * coinType.rawValue
}

print(totalMoney)

// 11.1 Encode
var code = [
    "a" : "b",
    "b" : "c",
    "c" : "d",
    "d" : "e",
    "e" : "f",
    "f" : "g",
    "g" : "h",
    "h" : "i",
    "i" : "j",
    "j" : "k",
    "k" : "l",
    "l" : "m",
    "m" : "n",
    "n" : "o",
    "o" : "p",
    "p" : "q",
    "q" : "r",
    "r" : "s",
    "s" : "t",
    "t" : "u",
    "u" : "v",
    "v" : "w",
    "w" : "x",
    "x" : "y",
    "y" : "z",
    "z" : "a"
]

var message = "hello world"
var encodedMessage = ""

for char in message {
    var character = "\(char)"

    if let encodedChar = code[character] {
        encodedMessage += encodedChar
    } else {
        encodedMessage += character
    }
}

print(encodedMessage)

// 11.2 Decode
var decoder: [String:String] = [:]
var decodedMessage = ""

for (key, value) in code {
    decoder[value] = key
}

for char in encodedMessage {
    var character = "\(char)"

    if let encodedChar = decoder[character] {
        decodedMessage += encodedChar
    } else {
        decodedMessage += character
    }
}

print(decodedMessage)

// 11.3 Names
var people: [[String:String]] = [
    [
        "firstName": "Calvin",
        "lastName": "Newton"
    ],
    [
        "firstName": "Garry",
        "lastName": "Mckenzie"
    ],
    [
        "firstName": "Leah",
        "lastName": "Rivera"
    ],
    [
        "firstName": "Sonja",
        "lastName": "Moreno"
    ],
    [
        "firstName": "Noel",
        "lastName": "Bowen"
    ]
]

var firstNames: [String] = []

for person in people {
    if let firstName = person["firstName"] {
        firstNames.append(firstName)
    }
}

// 11.5 Best score
var peopleWithScores: [[String:Any]] = [
    [
        "firstName": "Calvin",
        "lastName": "Newton",
        "score": 13
    ],
    [
        "firstName": "Garry",
        "lastName": "Mckenzie",
        "score": 23
    ],
    [
        "firstName": "Leah",
        "lastName": "Rivera",
        "score": 10
    ],
    [
        "firstName": "Sonja",
        "lastName": "Moreno",
        "score": 3
    ],
    [
        "firstName": "Noel",
        "lastName": "Bowen",
        "score": 16
    ]
]

var topPerson = people[0]
var bestScore = topPerson["score"] as! Int

for person in people {
    if let score = person["score"] as? Int {
        if bestScore < score  {
            bestScore = score
            topPerson = person
        }
    }
}

if let first = topPerson["firstName"] as? String,
   let second = topPerson["lastName"] as? String  {
    print("\(first) \(second)")
}

// 11.6 Frequency
var numbers = [1, 2, 3, 2, 3, 5, 2, 1, 3, 4, 2, 2, 2]
var frequency: [Int:Int] = [:]
var uniqueNumbers: [Int] = []

for number in numbers {
    if let oldFr = frequency[number] {
        frequency[number] = oldFr + 1
    } else {
        uniqueNumbers.append(number)
        frequency[number] = 1
    }
}

uniqueNumbers.sort(by: <)

for number in uniqueNumbers {
    print("\(number) \(frequency[number]!)")
}
